#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "6.0.0"
#endif
